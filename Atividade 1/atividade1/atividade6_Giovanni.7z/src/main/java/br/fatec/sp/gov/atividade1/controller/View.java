package br.fatec.sp.gov.atividade1.controller;

public class View {

    public static class PersonagemSimplificado {};

    public static class PersonagemCompleto extends PersonagemSimplificado {};
    
    
}
