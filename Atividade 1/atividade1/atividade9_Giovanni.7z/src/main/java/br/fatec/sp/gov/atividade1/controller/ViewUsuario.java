package br.fatec.sp.gov.atividade1.controller;

public class ViewUsuario {

    public static class UsuarioSimplificado {};

    public static class UsuarioCompleto extends UsuarioSimplificado {};
    
}
